package com.example.device_price_classification.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Device {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonProperty("battery_power")
    private int batteryPower;

    @JsonProperty("blue")
    private boolean blue;

    @JsonProperty("clock_speed")
    private double clockSpeed;

    @JsonProperty("dual_sim")
    private boolean dualSim;

    @JsonProperty("fc")
    private int fc;

    @JsonProperty("four_g")
    private boolean fourG;

    @JsonProperty("int_memory")
    private int intMemory;

    @JsonProperty("m_dep")
    private double mobileDepth;

    @JsonProperty("mobile_wt")
    private int mobileWeight;

    @JsonProperty("n_cores")
    private int nCores;

    @JsonProperty("pc")
    private int pc;

    @JsonProperty("px_height")
    private int pxHeight;

    @JsonProperty("px_width")
    private int pxWidth;

    @JsonProperty("ram")
    private int ram;

    @JsonProperty("sc_height")
    private int scHeight;

    @JsonProperty("sc_width")
    private int scWidth;

    @JsonProperty("talk_time")
    private int talkTime;

    @JsonProperty("three_g")
    private boolean threeG;

    @JsonProperty("touch_screen")
    private boolean touchScreen;

    @JsonProperty("wifi")
    private boolean wifi;

    @JsonProperty("price_range")
    private int priceRange; // Predicted price range.
}
