package com.example.device_price_classification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevicePriceClassificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevicePriceClassificationApplication.class, args);
	}

}
