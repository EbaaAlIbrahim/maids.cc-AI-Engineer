package com.example.device_price_classification.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import com.example.device_price_classification.PredictionService;
import com.example.device_price_classification.entity.Device;
import com.example.device_price_classification.service.DeviceService;

@RestController
@RequestMapping("/api/devices")
public class DeviceController {

    private final PredictionService predictionService;
    private final RestTemplate restTemplate;
    private final DeviceService deviceService;

    private static final String PYTHON_API_URL = "http://localhost:5000/predict";

    @Autowired
    public DeviceController(PredictionService predictionService, DeviceService deviceService, RestTemplate restTemplate) {
        this.predictionService = predictionService;
        this.deviceService = deviceService;
        this.restTemplate = restTemplate;
    }

    // Predict based on device specs sent in the request body
    @PostMapping("/predict")
    public String predictDevicePrice(@RequestBody Device device) {
        return predictionService.getPrediction(PYTHON_API_URL, device);
    }

    // Add a new device
    @PostMapping
    public ResponseEntity<Device> addDevice(@RequestBody Device device) {
        return ResponseEntity.ok(deviceService.saveDevice(device));
    }

    // Get a device by ID
    @GetMapping("/{id}")
    public ResponseEntity<Device> getDeviceById(@PathVariable Long id) {
        return deviceService.getDeviceById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Predict price for an existing device by ID via GET request
    @GetMapping("/predict/{id}")
public ResponseEntity<?> predictPriceById(@PathVariable Long id) {
    // Fetch device details by ID
    Device device = deviceService.getDeviceById(id)
            .orElseThrow(() -> new RuntimeException("Device not found"));

    // Prepare the specs for the Python API
    Map<String, Object> specs = new HashMap<>();
    specs.put("battery_power", device.getBatteryPower());
    specs.put("blue", device.isBlue());
    specs.put("clock_speed", device.getClockSpeed());
    specs.put("dual_sim", device.isDualSim());
    specs.put("fc", device.getFc());
    specs.put("four_g", device.isFourG());
    specs.put("int_memory", device.getIntMemory());
    specs.put("m_dep", device.getMobileDepth());
    specs.put("mobile_wt", device.getMobileWeight());
    specs.put("n_cores", device.getNCores());
    specs.put("pc", device.getPc());
    specs.put("px_height", device.getPxHeight());
    specs.put("px_width", device.getPxWidth());
    specs.put("ram", device.getRam());
    specs.put("sc_height", device.getScHeight());
    specs.put("sc_width", device.getScWidth());
    specs.put("talk_time", device.getTalkTime());
    specs.put("three_g", device.isThreeG());
    specs.put("touch_screen", device.isTouchScreen());
    specs.put("wifi", device.isWifi());

    try {
        // Call the Python API to get the prediction
        ResponseEntity<Map> response = restTemplate.postForEntity(PYTHON_API_URL, specs, Map.class);

        // Update the device with the predicted price range
        Map<String, Integer> predictionResponse = response.getBody();
        Integer predictedPrice = predictionResponse != null ? predictionResponse.get("prediction") : null;
        device.setPriceRange(predictedPrice);

        // Save the updated device back to the database
        deviceService.saveDevice(device);

        // Return the updated device
        return ResponseEntity.ok(device);
    } catch (Exception e) {
        // Handle any errors during the prediction or API call
        return ResponseEntity.status(500).body("Error predicting price: " + e.getMessage());
    }
}

}
