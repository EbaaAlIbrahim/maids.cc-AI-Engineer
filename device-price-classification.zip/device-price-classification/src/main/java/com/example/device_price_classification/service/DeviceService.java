package com.example.device_price_classification.service;

import com.example.device_price_classification.entity.Device;
import com.example.device_price_classification.repository.DeviceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;

@Service
public class DeviceService {
    @Autowired
    private DeviceRepository deviceRepository;

    // Save a new device
    public Device saveDevice(Device device) {
        return deviceRepository.save(device);
    }

    // Retrieve a device by its ID
    public Optional<Device> getDeviceById(Long id) {
        return deviceRepository.findById(id);
    }

   public List<Device> getAllDevices() {
       return deviceRepository.findAll();
   }
}
