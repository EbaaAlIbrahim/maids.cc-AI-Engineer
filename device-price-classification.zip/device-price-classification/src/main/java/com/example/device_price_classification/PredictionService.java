package com.example.device_price_classification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PredictionService {

    private final RestTemplate restTemplate;

    @Autowired
    public PredictionService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getPrediction(String apiUrl, Object requestPayload) {
        // Use RestTemplate to make a POST request to the Python API
        return restTemplate.postForObject(apiUrl, requestPayload, String.class);
    }
}
