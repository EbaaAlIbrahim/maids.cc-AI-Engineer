package com.example.device_price_classification;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevicePriceClassificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
