from flask import Flask, request, jsonify
import joblib
import numpy as np

# Load the trained model
model = joblib.load('device_price_classifier.pkl')

# Initialize Flask application
app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    # Extract input JSON data
    data = request.json

    required_keys = [
        'battery_power', 'blue', 'clock_speed', 'dual_sim', 'fc', 'four_g',
        'int_memory', 'm_dep', 'mobile_wt', 'n_cores', 'pc', 'px_height', 
        'px_width', 'ram', 'sc_height', 'sc_width', 'talk_time', 'three_g', 
        'touch_screen', 'wifi'
    ]

    # Check if any required keys are missing
    missing_keys = [key for key in required_keys if key not in data]
    if missing_keys:
        return jsonify({"error": f"Missing keys: {', '.join(missing_keys)}"}), 400

    # Continue processing if all keys are present
    try:
        features = np.array([
            data['battery_power'], data['blue'], data['clock_speed'],
            data['dual_sim'], data['fc'], data['four_g'], data['int_memory'],
            data['m_dep'], data['mobile_wt'], data['n_cores'], data['pc'],
            data['px_height'], data['px_width'], data['ram'], data['sc_height'],
            data['sc_width'], data['talk_time'], data['three_g'], data['touch_screen'],
            data['wifi']
        ]).reshape(1, -1)  # Reshape to 2D array for the model
    except KeyError as e:
        return jsonify({"error": f"Missing key: {str(e)}"}), 400

    # Make a prediction
    prediction = model.predict(features)[0]

    # Return the prediction as a JSON response
    return jsonify({"prediction": int(prediction)})

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)
